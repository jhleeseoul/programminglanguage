(* simple type error *)

if 1 then 1 else 1

(* result : type check failure *)
