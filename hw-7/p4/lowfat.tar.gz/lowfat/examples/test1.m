(* Simple expression *)

((1 = 1) and (true or false))

(* result : bool *)
