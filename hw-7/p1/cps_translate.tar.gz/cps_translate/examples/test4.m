(* Public testcase 4 : ifp *)

ifp ((fn b => b + 1) 0) then 1 else 2

(* Output : 1 *)
