(* Public testcase 1 : simple pair *)

let val p = (4, 5) in 
  write p.1 + p.2 
end 

(* Output : "9\n" *)


